# 分层记忆与自我进化

全局 / 用户 / 项目 / 分支 / 每日 五层记忆，支持自我进化

- **包名**：`dsh-memory-evolve`
- **版本**：`0.1.0`
- **类型**：插件
- **宿主**：DeepSeek Harness `0.1.7-alpha.2`

## 内容

本仓库是 分层记忆与自我进化 `0.1.0` 的源码快照，包含插件代码、配置、文档与安装清单。

运行时所需的资源文件、第三方二进制与依赖闭包体积较大，不进入 git，
随对应 Release 的完整包一并提供（见「安装」）。

## 安装

### 方式一：工作台安装（推荐）

工作台「工作台市场 → 从文件安装」，选择本仓库 Release 里的 `.tgz` 资产。

### 方式二：命令行安装

```bash
# 下载 Release 中的 .tgz，然后在 DSH profile 目录执行
dsh plugin add /path/to/dsh-memory-evolve-0.1.0.tgz
```

### 方式三：完整包（含全部运行时资源）

```bash
tar -xzf dsh-memory-evolve-0.1.0-full.tar.gz
# 解包后目录即插件运行态，可直接置入 profile 的 node_modules 下
```

## Release 资产说明

| 资产 | 用途 |
|---|---|
| `dsh-memory-evolve-0.1.0.tgz` | 工作台 / `dsh plugin add` 直接安装 |
| `dsh-memory-evolve-0.1.0-full.tar.gz` | 完整运行态（含资源与依赖），离线还原用 |
| `Source code (zip/tar.gz)` | GitHub 自动生成的源码归档 |

## 目录

- `.gitignore` (1 个文件)
- `LICENSE` (1 个文件)
- `README-详细说明.md` (1 个文件)
- `README.en.md` (1 个文件)
- `README.md` (1 个文件)
- `cordis.patch.yml` (1 个文件)
- `docs/`
- `lib/`
- `package.json` (1 个文件)
- `pnpm-lock.yaml` (1 个文件)
- `scripts/`
- `skills/`
- `src/`
- `tsconfig.json` (1 个文件)
- `vendor/`

## 说明

本仓库为私有备份仓库，用于留存 分层记忆与自我进化 在 9.9 生产环境的实际运行版本。
